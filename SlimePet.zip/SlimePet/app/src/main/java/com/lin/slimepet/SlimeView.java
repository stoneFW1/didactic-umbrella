package com.lin.slimepet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.Calendar;
import java.util.Random;

/**
 * 果冻史莱姆：贝塞尔曲线勾出体形，径向渐变做通透感，
 * 顶部高光 + 玻璃边缘 + 高光眼，对标原神那种半透明软体感。
 */
public class SlimeView extends View {

    public interface Callback {
        void onTap();
        void onDoubleTap();
        void onLongPress();
        void onDrag(float dx, float dy);
        void onDragEnd();
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path body = new Path();
    private final Path tmp = new Path();
    private final RectF oval = new RectF();
    private final Random rnd = new Random();

    private long lastNow = 0L;
    private float squash = 0f, squashV = 0f;
    private float mood = 0f;
    private float lookX = 0f, lookY = 0f, lookTX = 0f, lookTY = 0f;
    private boolean blinking = false;
    private long blinkEnd = 0L, nextBlink = 0L;
    private boolean sleeping = false;
    private long lastAct = 0L, nextWander = 0L;

    private final int slop;
    private float downRawX, downRawY, lastRawX, lastRawY;
    private boolean down = false, dragging = false, longFired = false;
    private long lastTap = 0L;

    private Callback cb;

    private final float[] pX = new float[24];
    private final float[] pY = new float[24];
    private final float[] pV = new float[24];
    private final float[] pL = new float[24];
    private int pN = 0;

    private final Runnable longJob = new Runnable() {
        @Override
        public void run() {
            if (down && !dragging) {
                longFired = true;
                if (cb != null) cb.onLongPress();
            }
        }
    };

    public SlimeView(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        long now = SystemClock.uptimeMillis();
        lastAct = now;
        lastNow = now;
        nextBlink = now + 2600L;
        nextWander = now + 4200L;
    }

    public void setCallback(Callback c) {
        cb = c;
    }

    public void poke() {
        mood = Math.min(1f, mood + 0.24f);
        squashV += 3.4f;
        addHearts();
    }

    // ---------------- 触摸 ----------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float rx = e.getRawX();
        float ry = e.getRawY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                down = true;
                dragging = false;
                longFired = false;
                downRawX = lastRawX = rx;
                downRawY = lastRawY = ry;
                lastAct = SystemClock.uptimeMillis();
                sleeping = false;
                lookTX = clampf((e.getX() - getWidth() / 2f) / Math.max(1f, getWidth() / 2f));
                lookTY = clampf((e.getY() - getHeight() / 2f) / Math.max(1f, getHeight() / 2f));
                removeCallbacks(longJob);
                postDelayed(longJob, 550L);
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = rx - lastRawX;
                float dy = ry - lastRawY;
                lastRawX = rx;
                lastRawY = ry;
                if (!dragging && (Math.abs(rx - downRawX) + Math.abs(ry - downRawY)) > slop) {
                    dragging = true;
                    removeCallbacks(longJob);
                }
                if (dragging) {
                    lastAct = SystemClock.uptimeMillis();
                    if (cb != null) cb.onDrag(dx, dy);
                }
                lookTX = clampf((e.getX() - getWidth() / 2f) / Math.max(1f, getWidth() / 2f));
                lookTY = clampf((e.getY() - getHeight() / 2f) / Math.max(1f, getHeight() / 2f));
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                down = false;
                removeCallbacks(longJob);
                if (dragging) {
                    dragging = false;
                    if (cb != null) cb.onDragEnd();
                } else if (!longFired && e.getActionMasked() == MotionEvent.ACTION_UP) {
                    long now = SystemClock.uptimeMillis();
                    if (now - lastTap < 300L) {
                        lastTap = 0L;
                        if (cb != null) cb.onDoubleTap();
                    } else {
                        lastTap = now;
                        if (cb != null) cb.onTap();
                    }
                }
                longFired = false;
                return true;
            }

            default:
                break;
        }
        return super.onTouchEvent(e);
    }

    private static float clampf(float v) {
        return v < -1f ? -1f : (v > 1f ? 1f : v);
    }

    // ---------------- 动画状态 ----------------

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float dt = (now - lastNow) / 1000f;
        if (dt <= 0f || dt > 0.2f) dt = 0.033f;
        lastNow = now;
        float t = now / 1000f;

        squashV += (-150f * squash - 17f * squashV) * dt;
        squash += squashV * dt;
        if (squash > 0.34f) { squash = 0.34f; if (squashV > 0f) squashV = 0f; }
        if (squash < -0.26f) { squash = -0.26f; if (squashV < 0f) squashV = 0f; }

        lookX += (lookTX - lookX) * Math.min(1f, dt * 9f);
        lookY += (lookTY - lookY) * Math.min(1f, dt * 9f);

        if (!sleeping) {
            if (!blinking && now > nextBlink) {
                blinking = true;
                blinkEnd = now + 120L;
            }
            if (blinking && now > blinkEnd) {
                blinking = false;
                nextBlink = now + 2400L + rnd.nextInt(4200);
            }
        }

        mood *= (float) Math.pow(0.985, dt * 60.0);

        if (!sleeping && !down && now - lastAct > 180000L) {
            sleeping = true;
        }

        if (!down && now > nextWander) {
            nextWander = now + 2600L + rnd.nextInt(4200);
            lookTX = (rnd.nextFloat() - 0.5f) * 1.3f;
            lookTY = (rnd.nextFloat() - 0.5f) * 1.3f;
        }

        drawScene(c, t);
        postInvalidateDelayed(sleeping ? 80 : 33);
    }

    // ---------------- 绘制 ----------------

    private void drawScene(Canvas c, float t) {
        int w = getWidth();
        int h = getHeight();
        float cx = w * 0.5f;
        float groundY = h * 0.85f;
        float hw = w * 0.355f;
        float bh = h * 0.58f;

        float breath = (float) Math.sin(t * (sleeping ? 1.1 : 2.0)) * (sleeping ? 0.018f : 0.030f);
        float s = breath + squash;
        float sy = 1f - s;
        float sx = 1f + s * 0.5f;

        int light = 0, base = 0, dark = 0, pupil = 0, pupilLight = 0;
        Calendar cal = Calendar.getInstance();
        double hh = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0;
        double[] hs = timePalette(hh);
        double hue = hs[0], sat = hs[1], lig = hs[2];

        if (mood > 0.02f) {
            hue = lerpHue(hue, 342.0, mood * 0.5);
            sat = Math.min(95.0, sat + mood * 10.0);
            lig = Math.min(80.0, lig + mood * 6.0);
        } else if (mood < -0.02f) {
            hue = lerpHue(hue, 250.0, -mood * 0.45);
            sat = Math.max(30.0, sat + mood * 22.0);
            lig = Math.max(42.0, lig + mood * 14.0);
        }
        if (cal.get(Calendar.HOUR_OF_DAY) >= 22 || cal.get(Calendar.HOUR_OF_DAY) < 6) {
            hue = lerpHue(hue, 246.0, 0.28);
            sat -= 4.0;
        }
        if (sleeping) {
            hue = lerpHue(hue, 252.0, 0.40);
            sat -= 8.0;
            lig -= 4.0;
        }

        light = hsl(hue, sat - 6.0, lig + 17.0);
        base = hsl(hue, sat, lig);
        dark = hsl(hue, sat + 2.0, lig - 20.0);
        pupil = hsl(hue, 50.0, 15.0);
        pupilLight = hsl(hue, 58.0, 33.0);

        // 地面阴影
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x1F000000);
        float shW = hw * 0.95f * sx;
        oval.set(cx - shW, groundY - bh * 0.03f, cx + shW, groundY + bh * 0.13f);
        c.drawOval(oval, p);

        // 体表外的柔和光晕
        p.setShader(new RadialGradient(cx, groundY - bh * 0.55f, hw * 1.55f,
                new int[]{withAlpha(light, 0x3A), withAlpha(light, 0x00)},
                new float[]{0.52f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, groundY - bh * 0.55f, hw * 1.55f, p);
        p.setShader(null);

        c.save();
        c.translate(cx, groundY);
        c.scale(sx, sy);
        c.translate(-cx, -groundY);

        float wob = (float) Math.sin(t * 1.7f) * 0.026f + (float) Math.sin(t * 2.9f + 1.1f) * 0.012f;
        buildBody(cx, groundY, hw, bh, wob);

        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx - hw * 0.45f, groundY - bh * 0.95f, hw * 2.05f,
                new int[]{light, base, dark}, new float[]{0f, 0.52f, 1f}, Shader.TileMode.CLAMP));
        p.setAlpha(244);
        c.drawPath(body, p);
        p.setAlpha(255);
        p.setShader(null);

        c.save();
        c.clipPath(body);

        p.setShader(new RadialGradient(cx - hw * 0.40f, groundY - bh * 0.82f, hw * 0.92f,
                new int[]{0x8CFFFFFF, 0x00FFFFFF}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        p.setShader(new LinearGradient(0, groundY - bh * 0.58f, 0, groundY + bh * 0.04f,
                0x00000000, 0x40000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        p.setColor(0xF2FFFFFF);
        oval.set(cx - hw * 0.52f, groundY - bh * 0.88f, cx - hw * 0.20f, groundY - bh * 0.695f);
        c.drawOval(oval, p);

        // 顶部玻璃质感的厚边
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(hw * 0.13f);
        p.setShader(new LinearGradient(0, groundY - bh, 0, groundY * 0.55f,
                withAlpha(light, 0x50), withAlpha(light, 0x00), Shader.TileMode.CLAMP));
        c.drawPath(body, p);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);

        c.restore();

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.5f, hw * 0.05f));
        p.setColor(withAlpha(light, 0x66));
        c.drawPath(body, p);
        p.setStyle(Paint.Style.FILL);

        drawEyes(c, cx, groundY, hw, bh, pupil, pupilLight);
        drawMouth(c, cx, groundY, hw, bh, pupil);

        c.restore();

        // 睡着的小 z
        if (sleeping) {
            float bob = (float) Math.sin(t * 1.6) * hw * 0.06f;
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(hw * 0.30f);
            p.setColor(withAlpha(pupil, 0xB0));
            c.drawText("z", cx + hw * 0.62f, groundY - bh * 0.95f + bob, p);
            p.setTextSize(hw * 0.21f);
            p.setColor(withAlpha(pupil, 0x70));
            c.drawText("z", cx + hw * 0.86f, groundY - bh * 1.10f + bob, p);
        }

        drawParticles(c, 0.033f);
    }

    private void buildBody(float cx, float groundY, float hw, float bh, float wob) {
        body.reset();
        float topY = groundY - bh;
        float l = hw * (1f + wob);
        float r = hw * (1f - wob);
        body.moveTo(cx - l, groundY);
        body.cubicTo(cx - l, groundY - bh * 0.92f, cx - hw * 0.56f, topY, cx, topY);
        body.cubicTo(cx + hw * 0.56f, topY, cx + r, groundY - bh * 0.92f, cx + r, groundY);
        body.cubicTo(cx + hw, groundY + bh * 0.055f, cx + hw * 0.58f, groundY + bh * 0.085f, cx, groundY + bh * 0.085f);
        body.cubicTo(cx - hw * 0.58f, groundY + bh * 0.085f, cx - hw, groundY + bh * 0.055f, cx - hw, groundY);
        body.close();
    }

    private void drawEyes(Canvas c, float cx, float groundY, float hw, float bh, int pupil, int light) {
        float eyeDX = hw * 0.33f;
        float eyeY = groundY - bh * 0.50f;
        float ew = hw * 0.150f;
        float eh = bh * 0.105f;
        boolean closed = sleeping || blinking;

        for (int i = 0; i < 2; i++) {
            float ex = i == 0 ? cx - eyeDX : cx + eyeDX;
            if (closed) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(2f, hw * 0.055f));
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setColor(pupil);
                oval.set(ex - ew, eyeY - eh * 0.7f, ex + ew, eyeY + eh * 1.0f);
                c.drawArc(oval, 195f, 150f, false, p);
                p.setStyle(Paint.Style.FILL);
            } else {
                float dx = lookX * ew * 0.34f;
                float dy = lookY * eh * 0.34f;
                oval.set(ex - ew + dx, eyeY - eh + dy, ex + ew + dx, eyeY + eh + dy);
                p.setShader(new RadialGradient(ex + dx, eyeY + eh * 0.45f + dy, ew * 1.15f,
                        new int[]{pupil, pupilLight}, new float[]{0.35f, 1f}, Shader.TileMode.CLAMP));
                c.drawOval(oval, p);
                p.setShader(null);
                p.setColor(0xCCFFFFFF);
                c.drawCircle(ex - ew * 0.28f + dx, eyeY - eh * 0.42f + dy, ew * 0.40f, p);
            }
        }

        // 腮红
        if (!sleeping && mood > 0.28f) {
            int a = (int) Math.min(110f, 40f + mood * 80f);
            float bl = eyeDX + hw * 0.20f;
            float by = eyeY + eh * 1.5f;
            p.setShader(new RadialGradient(bl, by, hw * 0.17f,
                    new int[]{withAlpha(0xF58AA8, a), withAlpha(0xF58AA8, 0)},
                    new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(bl, by, hw * 0.17f, p);
            c.drawCircle(cx * 2f - bl, by, hw * 0.17f, p);
            p.setShader(null);
        }
    }

    private void drawMouth(Canvas c, float cx, float groundY, float hw, float bh, int pupil) {
        float my = groundY - bh * 0.325f;
        p.setColor(pupil);
        if (sleeping) {
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, my, Math.max(1.6f, hw * 0.035f), p);
            return;
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.6f, hw * 0.042f));
        p.setStrokeCap(Paint.Cap.ROUND);
        float mw = mood > 0.25f ? hw * 0.115f : hw * 0.075f;
        oval.set(cx - mw, my - mw * 0.7f, cx + mw, my + mw * 1.1f);
        c.drawArc(oval, 20f, 140f, false, p);
        p.setStyle(Paint.Style.FILL);
    }

    // ---------------- 粒子 ----------------

    private void addHearts() {
        float w = getWidth(), h = getHeight();
        for (int i = 0; i < 3; i++) {
            if (pN >= pX.length) break;
            pX[pN] = w * 0.5f + (rnd.nextFloat() - 0.5f) * w * 0.42f;
            pY[pN] = h * 0.46f + rnd.nextFloat() * h * 0.10f;
            pV[pN] = h * 0.14f + rnd.nextFloat() * h * 0.10f;
            pL[pN] = 1.1f + rnd.nextFloat() * 0.6f;
            pN++;
        }
    }

    private void drawParticles(Canvas c, float dt) {
        int w2 = 0;
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < pN; i++) {
            float ny = pY[i] - pV[i] * dt;
            float nl = pL[i] - dt;
            if (nl > 0f) {
                pX[w2] = pX[i];
                pY[w2] = ny;
                pV[w2] = pV[i];
                pL[w2] = nl;
                int a = (int) Math.min(255f, nl * 220f);
                p.setColor(withAlpha(0xF06FA0, a));
                drawHeart(c, pX[w2], pY[w2], getWidth() * 0.028f);
                w2++;
            }
        }
        pN = w2;
    }

    private void drawHeart(Canvas c, float x, float y, float r) {
        tmp.reset();
        tmp.moveTo(x, y + r * 0.75f);
        tmp.cubicTo(x - r * 1.45f, y - r * 0.35f, x - r * 0.55f, y - r * 1.30f, x, y - r * 0.32f);
        tmp.cubicTo(x + r * 0.55f, y - r * 1.30f, x + r * 1.45f, y - r * 0.35f, x, y + r * 0.75f);
        tmp.close();
        c.drawPath(tmp, p);
    }

    // ---------------- 颜色 ----------------

    private static int withAlpha(int color, int a) {
        return (color & 0x00FFFFFF) | ((a & 0xFF) << 24);
    }

    private static int hsl(double h, double s, double l) {
        h = ((h % 360.0) + 360.0) % 360.0;
        s = Math.max(0.0, Math.min(100.0, s)) / 100.0;
        l = Math.max(0.0, Math.min(100.0, l)) / 100.0;
        double cc = (1.0 - Math.abs(2.0 * l - 1.0)) * s;
        double x = cc * (1.0 - Math.abs((h / 60.0) % 2.0 - 1.0));
        double m = l - cc / 2.0;
        double r = 0, g = 0, b = 0;
        int seg = (int) Math.floor(h / 60.0) % 6;
        if (seg == 0) { r = cc; g = x; }
        else if (seg == 1) { r = x; g = cc; }
        else if (seg == 2) { g = cc; b = x; }
        else if (seg == 3) { g = x; b = cc; }
        else if (seg == 4) { r = x; b = cc; }
        else { r = cc; b = x; }
        return Color.rgb(clamp255((int) Math.round((r + m) * 255)), clamp255((int) Math.round((g + m) * 255)), clamp255((int) Math.round((b + m) * 255)));
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    private static double lerpHue(double a, double b, double f) {
        double d = b - a;
        if (d > 180.0) d -= 360.0;
        if (d < -180.0) d += 360.0;
        return ((a + d * f) % 360.0 + 360.0) % 360.0;
    }

    private static double[] timePalette(double hh) {
        double[][] keys = {
                {0.0, 250.0, 72.0, 64.0},
                {5.0, 252.0, 68.0, 66.0},
                {7.5, 162.0, 66.0, 68.0},
                {11.0, 104.0, 62.0, 64.0},
                {14.5, 34.0, 86.0, 64.0},
                {18.0, 292.0, 68.0, 68.0},
                {21.0, 234.0, 74.0, 64.0},
                {24.0, 250.0, 72.0, 64.0}
        };
        for (int i = 0; i < keys.length - 1; i++) {
            if (hh >= keys[i][0] && hh <= keys[i + 1][0]) {
                double f = (hh - keys[i][0]) / Math.max(0.001, keys[i + 1][0] - keys[i][0]);
                return new double[]{
                        lerpHue(keys[i][1], keys[i + 1][1], f),
                        keys[i][2] + (keys[i + 1][2] - keys[i][2]) * f,
                        keys[i][3] + (keys[i + 1][3] - keys[i][3]) * f
                };
            }
        }
        return new double[]{250.0, 72.0, 64.0};
    }
}
